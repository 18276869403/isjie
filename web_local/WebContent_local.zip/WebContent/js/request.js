requestConf = {
	domain : "http://111.229.116.160:8088/jeecg-boot/"
//	domain : window.location.origin + "/jeecg-boot/"
//	domain : "http://127.0.0.1:8088/jeecg-boot/"
//	domain : "http://111.229.116.160:8087/jeecg-boot/"
//	domain : "http://192.168.1.135:8087/jeecg-boot/"
}